package pset09.p1;

/**
 * This program is for testing purposes of the Fibonacci Serialization.
 * ONLY FOR TESTING PURPOSES
 * @author pwicke, sriegl
 * */
public class StandardSerializeTest {
	// ドラゴンは　まいにちに　と　まいばんに　ウサギさん　の　もんもん　です。　そして　わたし　の　もんもん　です。
	public static void main(String[] args) {		
		System.out.println(Fibonacci.fibonacci(9));
		System.out.println(Fibonacci.fibonacci(10));
		System.out.println(Fibonacci.fibonacci(12));
		System.out.println(Fibonacci.fibonacci(8));
	}

}
